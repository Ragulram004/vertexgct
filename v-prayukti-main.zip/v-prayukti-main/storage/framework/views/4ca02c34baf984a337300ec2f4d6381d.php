<h4
    <?php echo e($attributes->class(['fi-ta-empty-state-heading text-base font-semibold leading-6 text-gray-950 dark:text-white'])); ?>

>
    <?php echo e($slot); ?>

</h4>
<?php /**PATH R:\TECHNICAL\Projects\GCT\v-prayukti-main\vendor\filament\tables\src\/../resources/views/components/empty-state/heading.blade.php ENDPATH**/ ?>